/** @type {import('next').NextConfig} */
const isGithubPages = process.env.GITHUB_PAGES === 'true';
const basePath = isGithubPages ? (process.env.NEXT_PUBLIC_BASE_PATH || '') : '';

const nextConfig = {
  transpilePackages: ['lunar-javascript'],
  ...(isGithubPages ? {
    output: 'export',
    trailingSlash: true,
    basePath,
    images: { unoptimized: true },
  } : {}),
};

module.exports = nextConfig;
