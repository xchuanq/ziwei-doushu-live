# 部署

本仓库的默认目标平台是 GitHub Pages，也支持 Vercel 和普通 Node.js 主机。

## GitHub Pages

推送到 `main` 后，[`pages.yml`](./.github/workflows/pages.yml) 会自动：

1. 安装依赖并运行类型检查；
2. 运行排盘回归；
3. 静态导出到 `out/`；
4. 发布到 GitHub Pages。

仓库名不是用户主页仓库时，站点地址通常是：

```text
https://<owner>.github.io/<repository>/
```

工作流会自动配置 `NEXT_PUBLIC_BASE_PATH` 和 `NEXT_PUBLIC_SITE_URL`。第一次运行时，
如果仓库尚未启用 Pages，`actions/configure-pages` 会尝试启用它。

## Vercel

导入仓库后保持默认的 Next.js 配置即可。建议设置：

```text
NEXT_PUBLIC_SITE_URL=https://your-domain.example
```

开源版不包含 `/api/interpret` 和 `/api/heming`，所以不配置 AI API Key 也可以正常排盘；
相关按钮会显示“开源版不含该接口”。

## 普通 Node.js 主机

```bash
npm ci
npm run typecheck
npm test
npm run build
NEXT_PUBLIC_SITE_URL=https://your-domain.example npm start
```

默认监听 `3000` 端口。生产环境建议由 Nginx、Caddy 或云平台负载均衡器终止 TLS。
