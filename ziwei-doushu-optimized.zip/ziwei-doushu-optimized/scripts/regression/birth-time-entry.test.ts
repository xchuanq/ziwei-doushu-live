import { strict as assert } from 'node:assert';
import { generateChart } from '../../lib/ziwei/algorithm';
import { resolveBirthTime } from '../../lib/ziwei/birth-time';
import type { BirthInfo, ZiweiChart } from '../../lib/ziwei/types';

function fingerprint(chart: ZiweiChart) {
  return {
    date: [
      chart.birthInfo.year,
      chart.birthInfo.month,
      chart.birthInfo.day,
      chart.birthInfo.hour,
    ],
    mingGong: chart.mingGongBranch,
    shenGong: chart.shenGongBranch,
    wuxingJu: chart.wuxingJu,
    palaces: chart.palaces.map(({ name, branch, stars }) => [
      name,
      branch,
      stars.map(({ name: starName, siHua }) => [starName, siHua]),
    ]),
  };
}

const raw: BirthInfo = {
  year: 2025,
  month: 12,
  day: 31,
  hour: 0,
  gender: 'male',
  longitude: 100,
  origInput: {
    year: 2025,
    month: 12,
    day: 31,
    clockHour: 23,
    clockMinute: 30,
  },
};

const resolved = resolveBirthTime(raw);
assert.deepEqual(
  [resolved.year, resolved.month, resolved.day, resolved.hour],
  [2025, 12, 31, 11],
  'late Zi at 100E should stay on the current day when true solar time is still in Hai',
);
assert.deepEqual(
  fingerprint(generateChart(raw)),
  fingerprint(generateChart(resolved)),
  'generateChart should resolve origInput and remain idempotent for resolved input',
);

const noClock: BirthInfo = {
  year: 1990,
  month: 1,
  day: 1,
  hour: 3,
  gender: 'female',
  longitude: 80,
};
assert.deepEqual(resolveBirthTime(noClock), noClock, 'missing origInput must remain backward compatible');

let invalidGenderThrew = false;
try {
  generateChart({ ...noClock, gender: 'unknown' as BirthInfo['gender'] });
} catch (error) {
  invalidGenderThrew = error instanceof RangeError;
}
assert.equal(invalidGenderThrew, true, 'invalid runtime gender should throw');

let invalidClockThrew = false;
try {
  resolveBirthTime({
    ...noClock,
    origInput: { year: 1990, month: 1, day: 1, clockHour: 24, clockMinute: 0 },
  });
} catch (error) {
  invalidClockThrew = error instanceof RangeError;
}
assert.equal(invalidClockThrew, true, 'invalid clock time should throw');

console.log('birth-time entry regressions passed');
