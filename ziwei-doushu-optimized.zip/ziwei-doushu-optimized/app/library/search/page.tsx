import { Suspense } from 'react';
import SearchClient from './SearchClient';

export const metadata = {
  title: '搜索 · 古籍原典库',
};

export default function SearchPage() {
  return (
    <Suspense fallback={<main style={{ padding: 40, textAlign: 'center' }}>正在加载古籍搜索…</main>}>
      <SearchClient />
    </Suspense>
  );
}
