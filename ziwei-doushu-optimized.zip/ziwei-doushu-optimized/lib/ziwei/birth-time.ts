import type { BirthInfo } from './types';
import {
  calculateTrueSolarTime,
  resolveZiweiDayOffset,
  shiftGregorianDate,
  type LateZishiRule,
} from './true-solar-time';

export interface ResolveBirthTimeOptions {
  /** 晚子时换日口径；默认按次日排盘。 */
  lateZishi?: LateZishiRule;
}

function assertValidClock(hour: number, minute: number): void {
  if (!Number.isInteger(hour) || hour < 0 || hour > 23) {
    throw new RangeError(`clockHour must be an integer from 0 to 23; received ${hour}`);
  }
  if (!Number.isInteger(minute) || minute < 0 || minute > 59) {
    throw new RangeError(`clockMinute must be an integer from 0 to 59; received ${minute}`);
  }
}

/**
 * Convert the original wall-clock input into chart-ready Zi Wei time.
 *
 * `BirthInfo.year/month/day/hour` are chart-ready values, while `origInput`
 * preserves the user's original Gregorian date and clock time. When origInput
 * is available, this function applies true-solar correction and late-Zi day
 * rollover exactly once, regardless of whether the caller previously resolved
 * the surrounding fields.
 *
 * Inputs without origInput are returned unchanged for backward compatibility.
 */
export function resolveBirthTime(
  birthInfo: BirthInfo,
  options: ResolveBirthTimeOptions = {},
): BirthInfo {
  const original = birthInfo.origInput;
  if (!original) return birthInfo;

  assertValidClock(original.clockHour, original.clockMinute);
  const longitude = typeof birthInfo.longitude === 'number'
    && Number.isFinite(birthInfo.longitude)
    ? birthInfo.longitude
    : undefined;

  const solar = calculateTrueSolarTime({
    year: original.year,
    month: original.month,
    day: original.day,
    clockHour: original.clockHour,
    clockMinute: original.clockMinute,
    longitude,
    utcOffsetMinutes: birthInfo.utcOffsetMinutes,
  });

  if (!solar.dateValid) {
    throw new RangeError(
      `solar date does not exist: ${original.year}-${original.month}-${original.day}`,
    );
  }

  const dayOffset = resolveZiweiDayOffset(solar, options.lateZishi);
  const chartDate = shiftGregorianDate(
    { year: original.year, month: original.month, day: original.day },
    dayOffset,
  );

  return {
    ...birthInfo,
    ...chartDate,
    hour: solar.branch,
  };
}
